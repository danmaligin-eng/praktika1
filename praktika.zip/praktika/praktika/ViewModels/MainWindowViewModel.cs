using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using praktika.Models;
using praktika.Services;
using System.Windows;

namespace praktika.ViewModels;

public partial class MainWindowViewModel : ViewModelBase
{
    private readonly IWeatherService _weatherService;
    private readonly JsonStorageService _storage;

    [ObservableProperty] private string _cityName = "";
    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private string _errorMessage = "";
    [ObservableProperty] private WeatherInfo? _currentWeather;
    [ObservableProperty] private double _temperature;
    [ObservableProperty] private string _weatherIconUrl = "";
    [ObservableProperty] private string _currentTheme = "Светлая";

    public ObservableCollection<string> History { get; } = new();

    public MainWindowViewModel(IWeatherService weatherService, JsonStorageService storage)
    {
        _weatherService = weatherService;
        _storage = storage;
        LoadState();
    }

    private void LoadState()
    {
        var state = _storage.Load();
        if (!string.IsNullOrEmpty(state.LastCity)) CityName = state.LastCity;
        
        History.Clear();
        foreach (var city in state.History) History.Add(city);
        
        if (state.Theme == "Dark") ApplyDarkTheme();
    }

    private void ApplyDarkTheme()
    {
        var app = Application.Current;
        if (app != null)
        {
            app.Resources["BackgroundBrush"] = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(30, 30, 30));
            app.Resources["ForegroundBrush"] = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 255, 255));
            CurrentTheme = "Тёмная";
        }
    }

    private void ApplyLightTheme()
    {
        var app = Application.Current;
        if (app != null)
        {
            app.Resources["BackgroundBrush"] = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 255, 255));
            app.Resources["ForegroundBrush"] = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 0, 0));
            CurrentTheme = "Светлая";
        }
    }

    [RelayCommand]
    private async Task SearchAsync()
    {
        if (string.IsNullOrWhiteSpace(CityName)) return;

        IsBusy = true;
        ErrorMessage = "";
        CurrentWeather = null;

        try
        {
            var data = await _weatherService.GetWeatherAsync(CityName);
            CurrentWeather = data;
            Temperature = data!.Main!.TempKelvin - 273.15; // Конвертация в Цельсий
            WeatherIconUrl = $"https://openweathermap.org/img/wn/{data.Weather![0].Icon}@2x.png";

            if (!History.Contains(CityName))
            {
                History.Insert(0, CityName);
                if (History.Count > 10) History.RemoveAt(10);
            }

            _storage.Save(new AppState(CityName, CurrentTheme == "Тёмная" ? "Dark" : "Light", History.ToList()));
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Ошибка: {ex.Message}";
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    private void ToggleTheme()
    {
        if (CurrentTheme == "Светлая") ApplyDarkTheme();
        else ApplyLightTheme();
        
        _storage.Save(new AppState(CityName, CurrentTheme == "Тёмная" ? "Dark" : "Light", History.ToList()));
    }

    [RelayCommand]
    private async Task SelectFromHistory(string city)
    {
        CityName = city;
        await SearchAsync(); // 🔧 Прямой вызов метода
    }
}