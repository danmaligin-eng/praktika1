using CommunityToolkit.Mvvm.ComponentModel;

namespace praktika.ViewModels;

public partial class ViewModelBase : ObservableObject { }