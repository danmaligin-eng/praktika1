using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace praktika.Models;

public class WeatherInfo
{
    [JsonPropertyName("name")] public string? CityName { get; set; }
    [JsonPropertyName("main")] public MainData? Main { get; set; }
    [JsonPropertyName("weather")] public List<WeatherDescription>? Weather { get; set; }
    [JsonPropertyName("wind")] public WindData? Wind { get; set; }
}

public class MainData
{
    [JsonPropertyName("temp")] public double TempKelvin { get; set; }
    [JsonPropertyName("humidity")] public int Humidity { get; set; }
    [JsonPropertyName("pressure")] public int Pressure { get; set; }
}

public class WeatherDescription
{
    [JsonPropertyName("description")] public string? Description { get; set; }
    [JsonPropertyName("icon")] public string? Icon { get; set; }
}

public class WindData
{
    [JsonPropertyName("speed")] public double Speed { get; set; }
}