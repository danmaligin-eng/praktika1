using praktika.Models;

namespace praktika.Services;

public interface IWeatherService
{
    Task<WeatherInfo?> GetWeatherAsync(string city);
}