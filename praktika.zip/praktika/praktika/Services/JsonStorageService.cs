using System.Text.Json;
using System.Collections.Generic;
using System.IO;

namespace praktika.Services;

public record AppState(string? LastCity, string Theme, List<string> History);

public class JsonStorageService
{
    private readonly string _filePath;

    public JsonStorageService()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "praktika");
        Directory.CreateDirectory(dir);
        _filePath = Path.Combine(dir, "state.json");
    }

    public AppState Load()
    {
        if (!File.Exists(_filePath)) 
            return new AppState(null, "Light", new List<string>());
        
        var json = File.ReadAllText(_filePath);
        return JsonSerializer.Deserialize<AppState>(json) ?? new AppState(null, "Light", new List<string>());
    }

    public void Save(AppState state)
    {
        var json = JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(_filePath, json);
    }
}