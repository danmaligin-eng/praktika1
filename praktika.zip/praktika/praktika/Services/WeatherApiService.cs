using System.Net.Http;
using System.Net.Http.Json;
using praktika.Models;

namespace praktika.Services;

public class WeatherApiService : IWeatherService
{
    private readonly HttpClient _http;
    private readonly string _apiKey;

    public WeatherApiService(HttpClient http, string apiKey)
    {
        _http = http;
        _apiKey = apiKey;
    }

    public async Task<WeatherInfo?> GetWeatherAsync(string city)
    {
        var url = $"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={_apiKey}&lang=ru";
        var response = await _http.GetAsync(url);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<WeatherInfo>();
    }
}