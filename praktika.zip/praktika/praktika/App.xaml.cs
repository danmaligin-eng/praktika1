﻿using System.Net.Http;
using System.Windows;
using praktika.Services;
using praktika.ViewModels;

namespace praktika;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        
        string apiKey = "424e4f368d711dec737d3b07b9cf3b40"; 
        
        var http = new HttpClient();
        var storage = new JsonStorageService();
        var viewModel = new MainWindowViewModel(new WeatherApiService(http, apiKey), storage);
        
        if (Current.MainWindow is MainWindow mainWindow)
        {
            mainWindow.DataContext = viewModel;
        }
    }
}