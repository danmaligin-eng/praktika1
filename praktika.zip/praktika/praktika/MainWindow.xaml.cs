﻿using System.Windows;

namespace praktika; 

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}